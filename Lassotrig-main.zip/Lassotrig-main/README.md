# Lassotrig
This is a collection of MATLAB codes to reproduce all the figures in the paper "Lasso trigonometric polynomial approximation for periodic
function recovery in equidistant points" by Congpei An and Mou Cai, which is available on https://doi.org/10.1016/j.apnum.2023.09.001.
